

window.onload=function (){//页面加载时根据本周的起始时间传入数据
  
	document.getElementById("middle").click();
	
}

